<!DOCTYPE html>
<html>
<head>
	<title>Edit</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(('../css/style.css')); ?>">
</head>
<body>
<div class="container">
<form method="POST" action="/save">
<?php echo e(csrf_field()); ?>

<div class="form-input">
	<input type="hidden" name="id" value="<?php echo e($student->id); ?>" ><br>
	<br><br>s
	<input type="text" name="idnum" value="<?php echo e($student->idnum); ?>" placeholder="ID Number"><br>

	<input type="text" name="fname" value="<?php echo e($student->fname); ?>" placeholder="First Name"><br>

	<input type="text" name="lname" value="<?php echo e($student->lname); ?>" placeholder="Last Name"><br>

	<input type="number" name="age" value="<?php echo e($student->age); ?>" placeholder="Age"><br>


	<input type="number" name="contact" value="<?php echo e($student->contact); ?>" placeholder="Contact"><br>

	<input type="text" name="program" value="<?php echo e($student->program); ?>" placeholder="Program"><br>

	<input type="text" name="address" value="<?php echo e($student->address); ?>" placeholder="Address"><br>

	<input type="text" name="guardian" value="<?php echo e($student->guardian); ?>" placeholder="Guardian"><br>

		<input type="submit" value="Save" class="save">
		</div>
</form>
</div>
</body>
</html>