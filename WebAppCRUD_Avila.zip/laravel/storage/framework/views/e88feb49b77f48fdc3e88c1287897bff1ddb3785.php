<!DOCTYPE html>
<html>
<head>
	<title>Student's List</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(('css/style.css')); ?>">
</head>
<body >
<div class="container">
<img src="../img/images.jpg" alt="">
<form method="POST" action="/addstudent">

	<?php echo e(csrf_field()); ?>

	<div class="form-input">

		<br><br> <input  type="number" name="idnum" placeholder="ID Number">
		</div>	
	<div class="form-input">
		 <input  type="text" name="fname" placeholder="First Name"><br>
		</div>	
	<div class="form-input">
		 <input  type="text" name="lname" placeholder="Last Name "><br>
		</div>	
	<div class="form-input">
	 	 <input  type="number" name="age" placeholder="Age"><br>
		</div>	
	<div class="form-input">
		  <input  type="number" name="contact" placeholder="Contact"><br>
		</div>	
	<div class="form-input">
		  <input  type="text" name="address" placeholder="Address"><br>
		</div>	
	<div class="form-input">
		  <input  type="text" name="program" placeholder="Program"><br>
		</div>	
	<div class="form-input">
		  <input  type="text" name="guardian" placeholder="Guardian"><br>
	</div>	
	<button type="submit" class="btn-login">ADD</button>
	<button type="reset" class="btn-reset">RESET</button>

	

</form>

</div><br>
<hr>
<div class="container2" style="overflow-x:auto;">
<table  class="table">
	<tr>
		<th hidden> ID </th>
		<th> ID Number </th>
		<th> Name </th>
		<th> Age </th>
		<th> Contact </th>
		<th> Address </th>
		<th> Program </th>
		<th> Guardian </th>
		<th> Options </th>
	</tr>
	<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($student->idnum); ?></td>
		<td><?php 
			$fullname= $student->fname. ' ' . $student->lname;
			echo $fullname;
		 ?></td>
		<td><?php echo e($student->age); ?></td>
		<td><?php echo e($student->contact); ?></td>
		<td><?php echo e($student->address); ?></td>
		<td><?php echo e($student->program); ?></td>
		<td><?php echo e($student->guardian); ?></td>
		<td>
			<button  class="button button-edit"> 
				<a href="/edit/<?php echo e($student->id); ?>">
				Edit
			</button>
			<button  class="button button-delete" >
				<a href="/delete/<?php echo e($student->id); ?>" color="red">
				Delete
			</button>

		


		</td>
		</tr><br><br>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</div>

</body>

</html>