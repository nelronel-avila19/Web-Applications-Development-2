<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;

class StudentController extends Controller
{
   public function home(Request $request){
   		$students = Student::all();
   		return view('index', compact('students'));
   }
   public function addStudent(Request $request){
   		$id = $request->id;
   		$idnum = $request->idnum;
   		$fname = $request->fname;
   		$lname = $request->lname;
   		$age = $request->age;
   		$contact = $request->contact;
   		$address = $request->address;
   		$program = $request->program;
   		$guardian = $request->guardian;
   		

   		$student = new Student;
   		$student->id=$id;
   		$student->idnum=$idnum;
   		$student->fname=$fname;
   		$student->lname=$lname;
   		$student->age=$age;
   		$student->contact=$contact;
   		$student->address=$address;
   		$student->program=$program;
   		$student->guardian=$guardian;
   		$student->save();

   		return redirect('/students');
   }
   public function editID(Request $request, $id){
         $id = $request->id;
   		$student = Student::find($id);
   		return view('edit', compact('student'));
   }
   public function save(Request $request){
   		$id = $request->id;
   		$idnum = $request->idnum;
   		$fname = $request->fname;
   		$lname = $request->lname;
   		$age = $request->age;
   		$contact = $request->contact;
   		$address = $request->address;
   		$program = $request->program;
   		$guardian = $request->guardian;
   		

   		$student = Student::find($id);
   		$student->id=$id;
   		$student->idnum=$idnum;
   		$student->fname=$fname;
   		$student->lname=$lname;
   		$student->age=$age;
   		$student->contact=$contact;
   		$student->address=$address;
   		$student->program=$program;
   		$student->guardian=$guardian;
   		$student->save();

   		return redirect('/students');
   }
   public function deleteID(Request $request, $id){
         $id = $request->id;
			$student = Student::find($id);
			$student->delete();
   		return redirect('/students');

   }
}
