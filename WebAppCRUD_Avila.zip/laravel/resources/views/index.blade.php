<!DOCTYPE html>
<html>
<head>
	<title>Student's List</title>
	<link rel="stylesheet" type="text/css" href="{{('css/style.css')}}">
</head>
<body >
<div class="container">
<img src="../img/images.jpg" alt="">
<form method="POST" action="/addstudent">

	{{ csrf_field() }}
	<div class="form-input">

		<br><br> <input  type="number" name="idnum" placeholder="ID Number">
		</div>	
	<div class="form-input">
		 <input  type="text" name="fname" placeholder="First Name"><br>
		</div>	
	<div class="form-input">
		 <input  type="text" name="lname" placeholder="Last Name "><br>
		</div>	
	<div class="form-input">
	 	 <input  type="number" name="age" placeholder="Age"><br>
		</div>	
	<div class="form-input">
		  <input  type="number" name="contact" placeholder="Contact"><br>
		</div>	
	<div class="form-input">
		  <input  type="text" name="address" placeholder="Address"><br>
		</div>	
	<div class="form-input">
		  <input  type="text" name="program" placeholder="Program"><br>
		</div>	
	<div class="form-input">
		  <input  type="text" name="guardian" placeholder="Guardian"><br>
	</div>	
	<button type="submit" class="btn-login">ADD</button>
	<button type="reset" class="btn-reset">RESET</button>

	

</form>

</div><br>
<hr>
<div class="container2" style="overflow-x:auto;">
<table  class="table">
	<tr>
		<th hidden> ID </th>
		<th> ID Number </th>
		<th> Name </th>
		<th> Age </th>
		<th> Contact </th>
		<th> Address </th>
		<th> Program </th>
		<th> Guardian </th>
		<th> Options </th>
	</tr>
	@foreach ($students as $student)
	<tr>
		<td>{{ $student->idnum }}</td>
		<td><?php 
			$fullname= $student->fname. ' ' . $student->lname;
			echo $fullname;
		 ?></td>
		<td>{{ $student->age }}</td>
		<td>{{ $student->contact }}</td>
		<td>{{ $student->address }}</td>
		<td>{{ $student->program }}</td>
		<td>{{ $student->guardian }}</td>
		<td>
			<button  class="button button-edit"> 
				<a href="/edit/{{ $student->id }}">
				Edit
			</button>
			<button  class="button button-delete" >
				<a href="/delete/{{ $student->id }}" color="red">
				Delete
			</button>

		


		</td>
		</tr><br><br>
		@endforeach
</table>
</div>

</body>

</html>