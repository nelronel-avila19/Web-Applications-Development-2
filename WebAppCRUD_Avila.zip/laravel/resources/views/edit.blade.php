<!DOCTYPE html>
<html>
<head>
	<title>Edit</title>
	<link rel="stylesheet" type="text/css" href="{{('../css/style.css')}}">
</head>
<body>
<div class="container">
<form method="POST" action="/save">
{{ csrf_field() }}
<div class="form-input">
	<input type="hidden" name="id" value="{{ $student->id }}" ><br>
	<br><br>
	<input type="text" name="idnum" value="{{ $student->idnum }}" placeholder="ID Number"><br>

	<input type="text" name="fname" value="{{ $student->fname }}" placeholder="First Name"><br>

	<input type="text" name="lname" value="{{ $student->lname }}" placeholder="Last Name"><br>

	<input type="number" name="age" value="{{ $student->age }}" placeholder="Age"><br>


	<input type="number" name="contact" value="{{ $student->contact }}" placeholder="Contact"><br>

	<input type="text" name="program" value="{{ $student->program }}" placeholder="Program"><br>

	<input type="text" name="address" value="{{ $student->address }}" placeholder="Address"><br>

	<input type="text" name="guardian" value="{{ $student->guardian }}" placeholder="Guardian"><br>

		<input type="submit" value="Save" class="save">
		</div>
</form>
</div>
</body>
</html>